import { db } from "@/db";
import {
  admins,
  couples,
  couplePreferences,
  tasks,
  timelineEvents,
  budgetCategories,
  expenses,
  decisions,
  prayers,
  devotions,
  coupleCommandments,
  quizQuestions,
  libraryBooks,
  articles,
  courses,
  guests,
  invitations,
  cagnotteContributions,
  dayJItems,
  dayJBlessings,
  payments,
} from "@/db/schema";
import { DEVOTIONAL_THEMES, DEFAULT_COMMANDMENTS } from "@/lib/constants";
import { eq } from "drizzle-orm";
import crypto from "crypto";

export function hashPassword(plainText: string): string {
  return crypto.createHash("sha256").update(plainText).digest("hex");
}

export async function seedDatabaseIfEmpty() {
  try {
    // 1. Seed Admin (identifiants configurables via variables d'environnement)
    const existingAdmins = await db.select().from(admins).limit(1);
    if (existingAdmins.length === 0) {
      await db.insert(admins).values({
        email: (process.env.ADMIN_EMAIL || "admin@weddingmood.ci").trim().toLowerCase(),
        passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "Admin@2025!WM"),
        name: process.env.ADMIN_NAME || "Direction Pastorale & Technique WM",
        role: "superadmin",
      });
    }

    // 2. Seed Devotions (7 themes)
    const existingDevotions = await db.select().from(devotions).limit(1);
    if (existingDevotions.length === 0) {
      for (const dev of DEVOTIONAL_THEMES) {
        await db.insert(devotions).values({
          themeNumber: dev.themeNumber,
          title: dev.title,
          scriptureRef: dev.scriptureRef,
          scriptureText: dev.scriptureText,
          teaching: dev.teaching,
          reflection: dev.reflection,
          coupleQuestion: dev.coupleQuestion,
          prayerModel: dev.prayerModel,
          pastorName: dev.pastorName,
          timelinePhase: dev.timelinePhase,
        });
      }
    }

    // 3. Seed Articles (Bon � savoir CI)
    const existingArticles = await db.select().from(articles).limit(1);
    if (existingArticles.length === 0) {
      await db.insert(articles).values([
        {
          title: "Guide complet du Mariage Civil en C�te d'Ivoire (Loi n� 2019-570)",
          slug: "mariage-civil-cote-divoire-loi-2019",
          category: "civil",
          organism: "Minist�re de la Justice et des Droits de l'Homme de C�te d'Ivoire",
          source: "Journal Officiel de la R�publique de C�te d'Ivoire",
          sourceUrl: "http://justice.gouv.ci",
          verifiedAt: "15 Janvier 2025",
          content: `Le mariage civil en C�te d'Ivoire est r�gi par la loi n� 2019-570 du 26 juin 2019. Voici les points capitaux :

1. �ge l�gal : L'�ge minimum requis pour contracter mariage est de 18 ans r�volus pour l'homme et la femme.
2. Comp�tence territoriale : La c�l�bration se fait devant l'Officier de l'�tat Civil (Maire ou adjoint) de la commune o� l'un des futurs �poux a son domicile ou sa r�sidence �tablie par un mois d'habitation continue.
3. Publication des bans : Obligatoire au moins dix (10) jours avant la c�l�bration � la mairie du lieu de c�l�bration et � celle du domicile de chaque �poux.
4. R�gimes matrimoniaux en C�te d'Ivoire :
   - R�gime l�gal : La Communaut� de biens r�duite aux acqu�ts (les biens acquis pendant le mariage sont communs, les biens d'avant mariage restent propres).
   - R�gime conventionnel : La S�paration de biens (�tabli par contrat notari� avant la c�l�bration).
5. Gestion de la famille : La loi ivoirienne de 2019 consacre la codirection de la famille par les deux �poux dans l'int�r�t moral et mat�riel du m�nage.`,
        },
        {
          title: "La Dot Traditionnelle en C�te d'Ivoire : Rites, Sens et Pratiques Chr�tiennes",
          slug: "dot-traditionnelle-cote-divoire-rites-foi",
          category: "dot",
          organism: "Conseil National des Rois et Chefs Traditionnels & �glises �vang�liques de CI",
          source: "�tude Pastorale & Anthropologique de C�te d'Ivoire",
          sourceUrl: "https://eglises.ci/dot-chretienne",
          verifiedAt: "20 Janvier 2025",
          content: `En C�te d'Ivoire, la dot est l'alliance entre deux familles avant le mariage civil et religieux.

- Chez les Akan (Baoul�, Agni, Ebri�, Atti�) : Rites de 'K�k�k�' (demande de consentement), remise de la liqueur d'ouverture, pagnes kita, bijoux en or, enveloppes d'honneur pour les parents et oncles maternels.
- Chez les Krou (B�t�, Gu�r�, W�, Dida) : Pr�sentation de la boisson de route, discussions d'anciens, symbolique de protection et d'hospitalit�.
- Chez les Mand� et Gour (Malink�, S�noufo, Yacouba) : Pri�res des patriarches, kola, b�tail et b�n�dictions des sages.

Conseils Pastoraux pour le Couple Chr�tien :
1. Rendre le Christ supr�me : Ne pratiquer aucun sacrifice d'animaux occulte ni libation d'adoration des anc�tres.
2. N�gocier avec amour et respect : �tablir un budget de dot r�aliste et refuser la surench�re.
3. Pri�re de sanctification : Consacrer chaque don et pr�sent � Dieu.`,
        },
        {
          title: "Les Pi�ces Administratives Obligatoires pour le Dossier de Mairie",
          slug: "pieces-administratives-mairie-abidjan",
          category: "documents",
          organism: "Mairie de Cocody / Plateau / Marcory / Yopougon",
          source: "Service d'�tat Civil des Communes de C�te d'Ivoire",
          sourceUrl: "https://mairie.ci",
          verifiedAt: "05 F�vrier 2025",
          content: `Pour d�poser votre dossier de mariage civil dans les mairies ivoiriennes, r�unissez :

1. Pour chacun des futurs �poux :
   - Un extrait d'acte de naissance d�livr� depuis moins de 3 mois (ou certificat tenant lieu d'acte).
   - Un certificat de r�sidence attestant d'au moins 30 jours dans la commune.
   - Un certificat pr�nuptial m�dical (d�livr� par un m�decin agr��).
   - Une photocopie l�galis�e de la CNI ou du Passeport en cours de validit�.
   - Deux photos d'identit� de m�me tirage.
   - Un certificat de c�libat ou de non-remariage.
2. Pour les t�moins (2 t�moins majeurs, un pour chaque �poux) :
   - Photocopie lisible de la CNI ou du Passeport.
   - Mention de leur profession et domicile.
3. En cas de contrat de mariage :
   - Le certificat du notaire attestant du contrat de s�paration de biens.`,
        },
        {
          title: "La B�n�diction Nuptiale : Exigences Spirituelles et Pastorales",
          slug: "benediction-nuptiale-eglise-pastoral",
          category: "eglise",
          organism: "F�d�ration �vang�lique et Protestante de C�te d'Ivoire",
          source: "Commission Pastorale du Mariage Chr�tien",
          sourceUrl: "https://fepci.org",
          verifiedAt: "10 Janvier 2025",
          content: `La b�n�diction nuptiale scelle l'alliance du couple devant Dieu et son assembl�e sainte.

�tapes cl�s recommand�es :
1. D�claration d'intention aupr�s du Pasteur au moins 6 mois avant la date.
2. Suivi des cours pr�nuptiaux pastoraux (8 � 12 s�ances obligatoires sur la communication, la sexualit� sainte, les finances et la pri�re).
3. Obtention du certificat pastoral de fin de pr�paration pr�nuptiale.
4. R�p�tition g�n�rale du culte de mariage (�change des alliances, v�ux, chants de la chorale, procession).`,
        },
      ]);
    }

    // 4. Seed Courses & Guides
    const existingCourses = await db.select().from(courses).limit(1);
    if (existingCourses.length === 0) {
      await db.insert(courses).values([
        {
          title: "Parcours Officiel Mairie : De la constitution du dossier au OUI civil",
          slug: "parcours-mairie-ivoirienne",
          category: "civil",
          description: "Guide m�thodologique pas-�-pas pour r�ussir vos d�marches administratives dans toutes les mairies de C�te d'Ivoire sans stress.",
          momentIdeal: "Entre J-90 et J-45",
          orderIndex: 1,
          requiredDocuments: [
            "Extraits d'acte de naissance (- de 3 mois)",
            "Certificats de r�sidence r�cents",
            "Certificats m�dicaux pr�nuptiaux",
            "Photocopies CNI certifi�es",
            "CNI des deux t�moins",
          ],
          steps: [
            { stepNumber: 1, title: "Retrait de la fiche de mariage", detail: "Rendez-vous au service �tat civil de votre mairie choisie pour retirer la pochette officielle." },
            { stepNumber: 2, title: "Bilan m�dical pr�nuptial", detail: "Effectuez vos bilans sanguins (groupe, rh�sus, �lectrophor�se d'h�moglobine AS/SS/AA, s�rologies)." },
            { stepNumber: 3, title: "D�p�t et Publication des Bans", detail: "D�posez le dossier complet au moins 15 jours avant la date pour affichage public l�gal de 10 jours." },
            { stepNumber: 4, title: "Entretien pr�-mariage", detail: "Rencontre avec l'officier d'�tat civil pour valider le r�gime matrimonial (communaut� ou s�paration)." },
          ],
          practicalTips: [
            "Faites au moins 3 photocopies certifi�es de chaque document.",
            "R�servez l'heure exacte de passage � la mairie t�t, surtout les samedis tr�s demand�s.",
            "D�signez un coordonnateur logistique d�di� aux livrets de famille et bagues le Jour J.",
          ],
          legalSources: [
            "Loi ivoirienne n� 2019-570 du 26 juin 2019 sur le mariage",
            "Code de proc�dure d'�tat civil de C�te d'Ivoire",
          ],
        },
        {
          title: "Parcours Dot Traditionnelle Chr�tienne : Honneur et Sanctification",
          slug: "parcours-dot-traditionnelle",
          category: "dot",
          description: "Comment organiser une dot honorable dans le respect des coutumes familiales ivoiriennes et dans la totale sanctification de l'�vangile.",
          momentIdeal: "Entre J-120 et J-60",
          orderIndex: 2,
          requiredDocuments: [
            "Liste officielle de dot remise par les patriarches",
            "Accord pr�alable sur le lieu (domicile familial de la fianc�e)",
            "Choix du porte-parole chr�tien de chaque d�l�gation",
          ],
          steps: [
            { stepNumber: 1, title: "La premi�re d�marche (K�k�k�)", detail: "Pr�sentation des intentions du jeune homme par son p�re ou oncle aupr�s de la famille de la fianc�e." },
            { stepNumber: 2, title: "Harmonisation pastorale de la liste", detail: "Revue conjointe avec les parents pour remplacer les �l�ments occultes ou excessifs par des pr�sents honorables." },
            { stepNumber: 3, title: "C�l�bration de l'alliance familiale", detail: "C�r�monie conviviale avec pri�re d'ouverture, remise des dons, repas et b�n�diction des a�n�s." },
          ],
          practicalTips: [
            "Pr�voyez un service traiteur ou des plats ivoiriens conviviaux (Atti�k� poisson brais�, Alloco, sauces traditionnelles).",
            "Restez serein face aux n�gociations amicales des oncles.",
            "Consacrez la journ�e par un temps de pri�re avant l'arriv�e des d�l�gations.",
          ],
          legalSources: [
            "Coutumiers traditionnels de C�te d'Ivoire",
            "Recommandations de l'Alliance �vang�lique de C�te d'Ivoire",
          ],
        },
      ]);
    }

    // 5. Seed Library Books
    const existingBooks = await db.select().from(libraryBooks).limit(1);
    if (existingBooks.length === 0) {
      await db.insert(libraryBooks).values([
        {
          title: "Les 5 Langages de l'Amour dans le Foyer Chr�tien",
          author: "Gary Chapman (Adaptation Pastorale Afrique de l'Ouest)",
          pastor: "�ditions Foyer Chr�tien Abidjan",
          category: "communication",
          description: "D�couvrez les cl�s indispensables pour combler le r�servoir �motionnel de votre conjoint : Paroles valorisantes, Moments de qualit�, Cadeaux sinc�res, Services rendus et Toucher physique.",
          bibleVerse: "1 Corinthiens 13:4-7",
          accessLevel: "all",
          readTimeMin: 20,
          chapters: [
            { title: "Chapitre 1 : Remplir le r�servoir d'amour", content: "Chaque �tre humain a un besoin vital de se sentir aim�. Dans le mariage, ce r�servoir se vide avec le rythme effr�n� du quotidien si nous ne connaissons pas la langue maternelle affective de notre conjoint..." },
            { title: "Chapitre 2 : Les Paroles de B�n�diction", content: "Les proverbes nous rappellent que la mort et la vie sont au pouvoir de la langue. Les compliments sinc�res, les encouragements dans les projets professionnels et spirituels b�tissent l'assurance..." },
            { title: "Chapitre 3 : Les Moments de Qualit� en Couple", content: "Passer du temps de qualit� ne signifie pas simplement �tre assis devant le m�me �cran, mais s'accorder une attention exclusive sans distraction t�l�phonique..." },
          ],
        },
        {
          title: "L'Argent, la Foi et la Prosp�rit� du Foyer",
          author: "Pasteur St�phane Bamba & Dr �pouse Bamba",
          pastor: "Centre Chr�tien de la Gr�ce - Cocody",
          category: "finances",
          description: "Un guide pratique pour les jeunes couples ivoiriens : comment b�tir un budget transparent en FCFA, �pargner pour le premier logement, honorer Dieu par la d�me et �viter l'endettement pour la noce.",
          bibleVerse: "Proverbes 21:20",
          accessLevel: "all",
          readTimeMin: 25,
          chapters: [
            { title: "Chapitre 1 : L'unit� financi�re en Christ", content: "Dieu ne b�nit pas la dissimulation. L'homme et la femme forment une seule chair, ce qui implique une transparence totale sur les revenus, les charges de famille et les projets d'investissement..." },
            { title: "Chapitre 2 : La gestion prudente du budget de mariage", content: "Ne commencez pas votre vie conjugale sous le poids de dettes �crasantes contract�es pour �pater une foule d'un jour. Un mariage r�ussi est celui o� la paix du lendemain est pr�serv�e..." },
            { title: "Chapitre 3 : La Cagnotte Premier Loyer et Investissement", content: "Anticipez imm�diatement les 3 � 6 mois de caution et loyer d'avance � Abidjan, ainsi que le fonds d'urgence de sant� et de foyer..." },
          ],
        },
        {
          title: "La Saintet� et la Joie de l'Intimit� dans le Mariage",
          author: "Pasteure Grace N'Guessan",
          pastor: "Minist�re Foi & Esp�rance Abidjan",
          category: "purete",
          description: "La vision biblique de la sexualit� et de la puret� : se pr�server dans la saintet� jusqu'� la nuit de noces et vivre une intimit� �panouie et sans culpabilit� selon le dessein de Dieu.",
          bibleVerse: "H�breux 13:4",
          accessLevel: "all",
          readTimeMin: 30,
          chapters: [
            { title: "Chapitre 1 : Le mariage est honorable en tout", content: "La sexualit� n'a pas �t� invent�e par le p�ch� mais par Dieu Lui-m�me pour c�l�brer l'unit� d'alliance entre un homme et une femme dans le mariage..." },
            { title: "Chapitre 2 : Garder son c�ur et son corps jusqu'au Jour J", content: "Les fian�ailles sont un temps de sanctification et d'apprentissage �motionnel. Poser des garde-fous clairs �vite les regrets et d�cuple la joie du jour de noces..." },
          ],
        },
      ]);
    }

    // 6. Seed Quiz Questions (Connaissance, Situations R�elles CI, Discussion Couple)
    const existingQuiz = await db.select().from(quizQuestions).limit(1);
    if (existingQuiz.length === 0) {
      await db.insert(quizQuestions).values([
        // Connaissance Biblique
        {
          category: "connaissance",
          question: "Selon Gen�se 2:24, que doit faire l'homme avant de devenir une seule chair avec sa femme ?",
          options: ["Construire une grande maison", "Quitter son p�re et sa m�re et s'attacher � sa femme", "Demander la dot � son village", "�crire un contrat d'alliance"],
          correctOptionIndex: 1,
          explanation: "La Parole de Dieu pose le double principe fondamental : quitter avec respect son foyer d'origine pour s'attacher et b�tir un nouveau foyer autonome.",
          bibleRef: "Gen�se 2:24",
          dayNumber: 1,
        },
        {
          category: "connaissance",
          question: "Dans �ph�siens 5, � quoi Paul compare-t-il l'amour d'un mari pour son �pouse ?",
          options: ["� l'amiti� de �poux et Jonathan", "� l'amour de Christ qui s'est livr� pour Son �glise", "� la sagesse du Roi Salomon", "� la puissance d'�lie sur le Mont Carmel"],
          correctOptionIndex: 1,
          explanation: "Christ a donn� Sa vie pour Son �glise : c'est un amour sacrificiel, protecteur et sanctificateur.",
          bibleRef: "�ph�siens 5:25",
          dayNumber: 1,
        },
        {
          category: "connaissance",
          question: "Que d�clare Proverbes 18:22 au sujet de celui qui trouve une femme ?",
          options: ["Il trouve le repos de son �me", "Il trouve le bonheur et obtient une faveur de l'�ternel", "Il trouve une conseill�re pour sa maison", "Il s'assure une post�rit� nombreuse"],
          correctOptionIndex: 1,
          explanation: "Trouver son conjoint selon le c�ur de Dieu est une gr�ce et une faveur de l'�ternel.",
          bibleRef: "Proverbes 18:22",
          dayNumber: 2,
        },
        {
          category: "connaissance",
          question: "Selon 1 Corinthiens 13:4-7, quel est le premier attribut de l'amour v�ritable ?",
          options: ["L'amour est impatient", "L'amour est plein de bont� et patient", "L'amour exige la perfection", "L'amour cherche son int�r�t"],
          correctOptionIndex: 1,
          explanation: "L'amour divin (Agap�) est patient, plein de bont�, ne soup�onne point le mal et excuse tout.",
          bibleRef: "1 Corinthiens 13:4",
          dayNumber: 2,
        },
        {
          category: "connaissance",
          question: "Quelle recommandation Paul donne-t-il dans �ph�siens 4:26 concernant la col�re dans le couple ?",
          options: ["Gardez le silence pendant trois jours", "Que le soleil ne se couche pas sur votre col�re", "Racontez votre diff�rend � vos beaux-parents", "Attendez le culte du dimanche"],
          correctOptionIndex: 1,
          explanation: "R�soudre les tensions le jour m�me �vite que l'ennemi ne prenne pied dans le c�ur et le foyer.",
          bibleRef: "�ph�siens 4:26",
          dayNumber: 3,
        },

        // Situations R�elles en C�te d'Ivoire
        {
          category: "situation_reelle",
          question: "Situation CI : Un oncle influent exige d'imposer 100 personnes de plus � la liste des invit�s de la r�ception sans participation financi�re. Comment r�agit le couple chr�tien avec sagesse ?",
          options: [
            "Lui crier dessus publiquement pour lui rappeler le budget",
            "S'endetter lourdement � la banque pour �viter toute g�ne",
            "Faire une visite respectueuse avec des pr�sents pour expliquer calmement la limite stricte de la salle tout en proposant une diffusion vid�o ou une visite post-mariage",
            "Annuler le mariage pour protester",
          ],
          correctOptionIndex: 2,
          explanation: "La sagesse ivoirienne chr�tienne allie l'honneur filial (d�marche en personne avec respect) et la fermet� budg�taire indispensable pour ne pas couler le m�nage.",
          ivorianContext: "Conflits de liste d'invit�s avec la famille �largie � Abidjan",
          bibleRef: "Proverbes 15:1",
          dayNumber: 1,
        },
        {
          category: "situation_reelle",
          question: "Situation CI : Deux semaines avant le mariage civil, le propri�taire de la maison convoit�e � Cocody augmente soudain la caution de 3 mois de loyer. Quelle est la d�marche prioritaire du couple ?",
          options: [
            "Prier ensemble, faire un point de tr�sorerie transparent et chercher une alternative s�curis�e sans paniquer ni s'accuser",
            "Accuser son futur conjoint de mauvaise gestion et bouder",
            "Prendre l'argent allou� � la dot pour payer",
            "Signer sans lire ni r�fl�chir",
          ],
          correctOptionIndex: 0,
          explanation: "Face aux impr�vus de logement � Abidjan, l'union dans la pri�re et la lucidit� financi�re renforcent le couple au lieu de le diviser.",
          ivorianContext: "Immobilier et premier loyer � Abidjan",
          bibleRef: "Philippiens 4:6-7",
          dayNumber: 2,
        },
        {
          category: "situation_reelle",
          question: "Situation CI : La belle-famille propose d'ajouter une c�r�monie �sot�rique traditionnelle la veille de la b�n�diction nuptiale pour 'prot�ger la fertilit�'. Que fait le couple ?",
          options: [
            "Accepter en cachette pour ne vexer personne",
            "Refuser avec violence et couper les ponts avec la famille",
            "Affirmer avec amour et douceur leur foi exclusive en J�sus-Christ comme seul protecteur et demander au pasteur d'interc�der avec eux",
            "Consulter un marabout",
          ],
          correctOptionIndex: 2,
          explanation: "Le chr�tien ne transige pas sur son all�geance � J�sus-Christ tout en r�pondant avec douceur et respect selon 1 Pierre 3:15.",
          ivorianContext: "Syncr�tisme et traditions lors des mariages coutumiers",
          bibleRef: "Josu� 24:15",
          dayNumber: 3,
        },

        // Discussion de Couple (QCD)
        {
          category: "discussion_couple",
          question: "Question de complicit� : Quel est le moment de notre journ�e que tu aimerais que nous consacrions exclusivement l'un � l'autre une fois mari�s ?",
          options: ["Le caf� du matin", "La pri�re du soir au coucher", "Le d�ner sans t�l�phone", "Une balade du weekend"],
          correctOptionIndex: 0,
          explanation: "Cette question ouvre un dialogue pr�cieux pour planifier vos rituels d'intimit� quotidienne.",
          dayNumber: 1,
        },
        {
          category: "discussion_couple",
          question: "Question financi�re : En cas de prime ou d'entr�e d'argent inattendue, quelle est notre priorit� commune ?",
          options: ["�pargne de secours pour le foyer", "Donner une offrande d'action de gr�ce � l'�glise", "Investir dans un projet commun", "Faire un voyage de noces inoubliable"],
          correctOptionIndex: 0,
          explanation: "Harmoniser vos visions financi�res renforce votre unit� d'action.",
          dayNumber: 2,
        },
        {
          category: "discussion_couple",
          question: "Question de vision : Dans 5 ans, quel t�moignage principal souhaites-tu que notre foyer chr�tien rende � notre entourage ?",
          options: ["Un couple d'accueil et d'amour pour les n�cessiteux", "Un mod�le de foi et d'�ducation pour nos enfants", "Une r�ussite professionnelle et spirituelle �quilibr�e", "Un pilier solide dans notre �glise locale"],
          correctOptionIndex: 0,
          explanation: "B�tir ensemble la vision de votre sanctuaire conjugal.",
          dayNumber: 3,
        },
      ]);
    }

    // 7. Seed Demo Couple: �poux & �pouse
    const demoCoupleSlug = "�poux-�pouse";
    const existingCouple = await db.select().from(couples).where(eq(couples.slug, demoCoupleSlug)).limit(1);

    let coupleId: number;

    if (existingCouple.length === 0) {
      const trialExpiry = new Date();
      trialExpiry.setDate(trialExpiry.getDate() + 3); // 3-day trial

      const [newCouple] = await db
        .insert(couples)
        .values({
          slug: demoCoupleSlug,
          partner1Name: "�poux Kouassi",
          partner2Name: "�pouse Yao",
          partner1Email: "�poux@weddingmood.ci",
          partner2Email: "�pouse@weddingmood.ci",
          partner1Role: "groom",
          partner2Role: "bride",
          partner1Photo: "https://images.pexels.com/photos/34887758/pexels-photo-34887758.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
          partner2Photo: "https://images.pexels.com/photos/37828098/pexels-photo-37828098.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=400&w=400",
          weddingDate: "2025-11-15",
          city: "Abidjan (Cocody & Riviera)",
          venue: "Palais de la Gr�ce & Espace Nuptial Riviera Golf",
          totalBudget: 6500000, // 6.5M FCFA
          estimatedGuests: 250,
          ceremonyTypes: ["dot", "civil", "benediction", "reception"],
          church: "�glise �vang�lique Gr�ce et Vie - Riviera",
          pastorName: "Pasteur Jean-Marc Kouadio",
          ethnicity: "Baoul� & B�t�",
          traditions: "Dot coutumi�re akan avec pagnes kita traditionnels et pr�sents honorifiques.",
          bibleVerse: "Eccl�siaste 4:12 - La corde � trois fils ne se rompt pas facilement.",
          status: "trial",
          trialEndsAt: trialExpiry,
          passwordHash: hashPassword("Amour@2025!"),
          sharedPasscode: "7777",
          accessCode: "WM-2025",
          planType: "couple",
          planAmount: 3000,
          partner1AccessActive: true,
          partner2AccessActive: true,
        })
        .returning();

      coupleId = newCouple.id;

      // Seed Preferences
      await db.insert(couplePreferences).values({
        coupleId: coupleId,
        themeId: 1, // Terracotta Royal
        fontFamily: "cormorant",
        displayMode: "standard",
        density: "normal",
        fontSize: "md",
        coverPhotoUrl: "https://images.pexels.com/photos/34887758/pexels-photo-34887758.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
        countdownStyle: "romantic",
      });

      // Seed 10 Commandments for couple
      for (const cmd of DEFAULT_COMMANDMENTS) {
        await db.insert(coupleCommandments).values({
          coupleId: coupleId,
          orderIndex: cmd.id,
          text: cmd.text,
          importanceWhy: cmd.importanceWhy,
          commitmentText: cmd.commitmentText,
          partner1Confirmed: true,
          partner2Confirmed: cmd.id <= 7, // partially confirmed to show progress
        });
      }

      // Seed Budget Categories
      const catResults = await db
        .insert(budgetCategories)
        .values([
          { coupleId, name: "C�r�monie & Dot Traditionnelle", allocatedAmount: 1200000, iconKey: "gift", colorKey: "terracotta", orderIndex: 1 },
          { coupleId, name: "Mairie & Frais d'�tat Civil", allocatedAmount: 250000, iconKey: "file-text", colorKey: "gold", orderIndex: 2 },
          { coupleId, name: "Tenues & Alliances Nuptiales", allocatedAmount: 1500000, iconKey: "sparkles", colorKey: "emerald", orderIndex: 3 },
          { coupleId, name: "Salle de R�ception & D�coration", allocatedAmount: 1800000, iconKey: "home", colorKey: "navy", orderIndex: 4 },
          { coupleId, name: "Service Traiteur & Boissons", allocatedAmount: 1200000, iconKey: "utensils", colorKey: "sage", orderIndex: 5 },
          { coupleId, name: "Photo, Vid�o & Drone", allocatedAmount: 400000, iconKey: "camera", colorKey: "bronze", orderIndex: 6 },
          { coupleId, name: "Sonorisation, Chantre & Musique", allocatedAmount: 250000, iconKey: "music", colorKey: "coral", orderIndex: 7 },
        ])
        .returning();

      const dotCatId = catResults[0]?.id;
      const mairieCatId = catResults[1]?.id;
      const tenuesCatId = catResults[2]?.id;
      const salleCatId = catResults[3]?.id;

      // Seed Expenses (With Dual Validation test case > 50,000 FCFA)
      await db.insert(expenses).values([
        {
          coupleId,
          categoryId: salleCatId,
          title: "Acompte R�servation Espace Riviera Golf",
          amount: 800000,
          advancePaid: 800000,
          remainingAmount: 0,
          dueDate: "2025-08-01",
          paymentStatus: "paid",
          recipient: "Direction Espace Riviera",
          requiresDualValidation: true,
          validationStatus: "approved_by_both",
          partner1Approved: true,
          partner2Approved: true,
          notes: "Re�u de versement conserv�. Salle climatis�e 300 places assises.",
        },
        {
          coupleId,
          categoryId: tenuesCatId,
          title: "Acompte Alliances Or 18K chez Bijouterie du Plateau",
          amount: 450000,
          advancePaid: 250000,
          remainingAmount: 200000,
          dueDate: "2025-09-15",
          paymentStatus: "partial",
          recipient: "Bijouterie Royale Plateau",
          requiresDualValidation: true,
          validationStatus: "approved_by_both",
          partner1Approved: true,
          partner2Approved: true,
          notes: "Gravure personnalis�e avec verset Eccl�siaste 4:12.",
        },
        {
          coupleId,
          categoryId: dotCatId,
          title: "Achat des Pagnes Kita traditionnels et pr�sents",
          amount: 350000,
          advancePaid: 150000,
          remainingAmount: 200000,
          dueDate: "2025-09-30",
          paymentStatus: "partial",
          recipient: "Ma�tre Tisserand Bomizambo",
          requiresDualValidation: true,
          validationStatus: "pending", // Pending �pouse's validation!
          partner1Approved: true,
          partner2Approved: false,
          notes: "En attente de validation conjointe pour le choix des motifs.",
        },
        {
          coupleId,
          categoryId: mairieCatId,
          title: "Frais de dossier et timbres fiscaux Mairie de Cocody",
          amount: 45000,
          advancePaid: 45000,
          remainingAmount: 0,
          dueDate: "2025-08-10",
          paymentStatus: "paid",
          recipient: "R�gie �tat Civil Cocody",
          requiresDualValidation: false, // < 50 000 FCFA
          validationStatus: "approved_by_both",
          partner1Approved: true,
          partner2Approved: true,
        },
      ]);

      // Seed Tasks
      await db.insert(tasks).values([
        {
          coupleId,
          title: "D�poser le dossier complet � la Mairie de Cocody",
          description: "V�rifier la validit� des extraits d'acte de naissance (- de 3 mois) et les certificats m�dicaux.",
          category: "civil",
          assignee: "him",
          dueDate: "2025-08-15",
          priority: "high",
          status: "completed",
          budgetEstimated: 50000,
          budgetActual: 45000,
        },
        {
          coupleId,
          title: "Confirmer le menu d�gustation avec le Traiteur",
          description: "S�lectionner 3 entr�es, buffet chaud (Tchep ivoirien, Foutou banane, M�rou brais�) et g�teau de noce.",
          category: "traiteur",
          assignee: "her",
          dueDate: "2025-09-20",
          priority: "high",
          status: "in_progress",
          budgetEstimated: 1200000,
          budgetActual: 0,
        },
        {
          coupleId,
          title: "Session 4 d'entretien pr�nuptial avec le Pasteur Jean-Marc",
          description: "Th�me de la s�ance : La gestion financi�re du foyer et la communication dans les �preuves.",
          category: "spirituel",
          assignee: "both",
          dueDate: "2025-09-25",
          priority: "urgent",
          status: "todo",
          budgetEstimated: 0,
          budgetActual: 0,
        },
        {
          coupleId,
          title: "Finaliser la liste des 250 invit�s et envoyer les liens d'invitation",
          description: "Attribuer les groupes (Famille, Jeunesse, Chorale, Amis, VIP) et activer le suivi RSVP en direct.",
          category: "reception",
          assignee: "both",
          dueDate: "2025-10-01",
          priority: "high",
          status: "in_progress",
        },
        {
          coupleId,
          title: "Essayage final de la robe de mari�e et du costume sur-mesure",
          description: "Prendre les derni�res retouches avec le couturier � Treichville.",
          category: "tenues",
          assignee: "both",
          dueDate: "2025-10-15",
          priority: "medium",
          status: "todo",
        },
      ]);

      // Seed Timeline Events (J-90 to Jour J)
      await db.insert(timelineEvents).values([
        { coupleId, phase: "J-90", title: "Entretien initial avec le Pasteur & D�but des cours", description: "Lancer le parcours des 7 th�mes d'�dification spirituelle.", category: "spirituel", isCompleted: true, orderIndex: 1 },
        { coupleId, phase: "J-90", title: "Fixation d�finitive de la date et r�servation de la salle", description: "Versement de l'acompte pour bloquer l'Espace Riviera Golf.", category: "reception", isCompleted: true, orderIndex: 2 },
        { coupleId, phase: "J-60", title: "C�l�bration de la Dot Traditionnelle au domicile familial", description: "Union des deux grandes familles selon les valeurs de l'�vangile.", category: "dot", isCompleted: true, orderIndex: 3 },
        { coupleId, phase: "J-60", title: "D�p�t officiel du dossier � la Mairie et publication des bans", description: "Affichage des bans l�gaux pendant 10 jours � la mairie.", category: "civil", isCompleted: true, orderIndex: 4 },
        { coupleId, phase: "J-30", title: "Envoi des invitations digitales et suivi des RSVP en direct", description: "Transmission du lien personnalis� aux 250 invit�s.", category: "invitations", isCompleted: false, orderIndex: 5 },
        { coupleId, phase: "J-30", title: "Validation finale du traiteur, de la d�coration et du photographe", description: "Confirmer le protocole, le chronogramme et les acomptes restants.", category: "logistique", isCompleted: false, orderIndex: 6 },
        { coupleId, phase: "J-14", title: "R�p�tition g�n�rale du culte de mariage � l'�glise", description: "R�p�tition avec les t�moins, demoiselles d'honneur, gar�ons d'honneur et la chorale.", category: "spirituel", isCompleted: false, orderIndex: 7 },
        { coupleId, phase: "J-7", title: "Dernier point de coordination et remise des livrets de messe", description: "V�rifier le chronogramme minute par minute avec le comit� de pilotage.", category: "logistique", isCompleted: false, orderIndex: 8 },
        { coupleId, phase: "J-1", title: "Veille du Jour J : Repos, recueillement et pri�re intime du couple", description: "Remettre la journ�e entre les mains de l'�ternel dans la paix du c�ur.", category: "spirituel", isCompleted: false, orderIndex: 9 },
        { coupleId, phase: "JOUR_J", title: "Le Grand Jour : C�l�bration Civile, B�n�diction Nuptiale et R�ception", description: "Que Dieu soit lou� pour cette alliance �ternelle !", category: "reception", isCompleted: false, orderIndex: 10 },
      ]);

      // Seed Decisions
      await db.insert(decisions).values([
        {
          coupleId,
          title: "Choix de l'Orchestre Gospel pour la R�ception",
          description: "Deux propositions re�ues : Groupe Louange Divine (350 000 FCFA) vs Chorale C�leste Live (450 000 FCFA avec cuivres).",
          amount: 450000,
          proposalDetails: "�pouse pr�f�re la Chorale C�leste Live pour leur r�pertoire de louange ivoirienne et contemporaine.",
          status: "approved",
          partner1Decision: "approved",
          partner2Decision: "approved",
          partner1Comment: "Je valide, leur prestation au mariage de Jean �tait remarquable.",
          partner2Comment: "Parfait mon amour, ils vont vraiment honorer Dieu pendant le banquet !",
        },
        {
          coupleId,
          title: "Option Photobooth & Borne � Selfie interactive pour les invit�s",
          description: "Proposition d'un prestataire pour installer une borne � selfie personnalis�e avec le logo Wedding Mood et nos pr�noms.",
          amount: 120000,
          proposalDetails: "Co�t : 120 000 FCFA pour 4 heures d'impression illimit�e.",
          status: "pending",
          partner1Decision: "pending",
          partner2Decision: "approved",
          partner1Comment: "Je v�rifie si le budget traiteur ne d�passe pas avant de confirmer.",
          partner2Comment: "Ce serait un magnifique souvenir pour la jeunesse et nos amis !",
        },
      ]);

      // Seed Prayer Journal
      await db.insert(prayers).values([
        {
          coupleId,
          title: "Pri�re pour la paix et l'harmonie entre nos deux familles",
          prayerText: "Seigneur J�sus, nous Te prions d'apaiser chaque c�ur lors des discussions de dot. Que l'amour, la compr�hension et le respect r�gnent en ma�tres.",
          category: "famille",
          prayerDate: "2025-07-10",
          isAnswered: true,
          testimony: "Gloire � Dieu ! La rencontre entre nos parents s'est d�roul�e dans une joie et une fraternit� extraordinaires.",
          status: "active",
          partner1Prayed: true,
          partner2Prayed: true,
        },
        {
          coupleId,
          title: "Pri�re pour la provision financi�re de notre premier loyer",
          prayerText: "P�re C�leste, Toi qui es notre pourvoyeur, b�nis le travail de nos mains. Accorde-nous la provision n�cessaire pour la caution et l'am�nagement de notre maison.",
          category: "finances",
          prayerDate: "2025-08-01",
          isAnswered: false,
          status: "active",
          partner1Prayed: true,
          partner2Prayed: true,
        },
        {
          coupleId,
          title: "Pri�re pour la cons�cration spirituelle de notre nuit de noces",
          prayerText: "Seigneur, nous Te confions notre intimit�. Sanctifie nos pens�es, donne-nous la douceur, la tendresse et la paix pour entrer dans cette alliance sacr�e.",
          category: "intimite",
          prayerDate: "2025-08-15",
          isAnswered: false,
          status: "active",
          partner1Prayed: true,
          partner2Prayed: true,
        },
      ]);

      // Seed Guests
      const guestList = [
        { firstName: "Pasteur Jean-Marc", lastName: "Kouadio", groupName: "vip", phone: "+225 07 01 02 03 04", email: "pasteur@eglisegrace.ci", plusOnesAllowed: 1, plusOnesConfirmed: 1, rsvpStatus: "confirmed", tableNumber: "Table d'Honneur", qrCodeToken: "WM-VIP-001", isCheckedIn: false },
        { firstName: "Koffi", lastName: "Kouassi (Oncle)", groupName: "famille", phone: "+225 05 11 22 33 44", plusOnesAllowed: 2, plusOnesConfirmed: 2, rsvpStatus: "confirmed", tableNumber: "Table Famille Akan", qrCodeToken: "WM-FAM-002", isCheckedIn: false },
        { firstName: "Ablan", lastName: "Yao (Maman)", groupName: "famille", phone: "+225 01 22 33 44 55", plusOnesAllowed: 2, plusOnesConfirmed: 2, rsvpStatus: "confirmed", tableNumber: "Table Famille Akan", qrCodeToken: "WM-FAM-003", isCheckedIn: false },
        { firstName: "Serge", lastName: "Dago (T�moin Mari�)", groupName: "amis", phone: "+225 07 44 55 66 77", email: "serge.dago@gmail.com", plusOnesAllowed: 1, plusOnesConfirmed: 1, rsvpStatus: "confirmed", tableNumber: "Table des T�moins", qrCodeToken: "WM-TEM-004", isCheckedIn: false },
        { firstName: "Esther", lastName: "Kouam� (T�moin Mari�e)", groupName: "amis", phone: "+225 05 66 77 88 99", email: "esther.k@gmail.com", plusOnesAllowed: 1, plusOnesConfirmed: 1, rsvpStatus: "confirmed", tableNumber: "Table des T�moins", qrCodeToken: "WM-TEM-005", isCheckedIn: false },
        { firstName: "Chorale", lastName: "Gr�ce C�leste", groupName: "chorale", phone: "+225 07 88 99 00 11", plusOnesAllowed: 15, plusOnesConfirmed: 12, rsvpStatus: "confirmed", tableNumber: "Table Chorale", qrCodeToken: "WM-CHO-006", isCheckedIn: false },
        { firstName: "Marc", lastName: "Boni", groupName: "collegues", phone: "+225 01 99 88 77 66", plusOnesAllowed: 1, plusOnesConfirmed: 0, rsvpStatus: "pending", tableNumber: "Table Entreprise", qrCodeToken: "WM-COL-007", isCheckedIn: false },
        { firstName: "Priscille", lastName: "N'Dri", groupName: "jeunesse", phone: "+225 07 12 34 56 78", plusOnesAllowed: 0, plusOnesConfirmed: 0, rsvpStatus: "confirmed", tableNumber: "Table Jeunesse", qrCodeToken: "WM-JEU-008", isCheckedIn: false },
      ];

      for (const g of guestList) {
        await db.insert(guests).values({
          coupleId,
          ...g,
        });
      }

      // Seed Public Invitation Website
      await db.insert(invitations).values({
        coupleId,
        slug: demoCoupleSlug,
        heroTitle: "�poux & �pouse � Unis par la Gr�ce de Dieu",
        loveStory: "Notre histoire a d�but� au sein du groupe de jeunesse de l'�glise en 2021. � travers les temps de pri�re, les partages fraternels et les projets communs, Dieu a r�v�l� Son dessein bienveillant pour nos vies. Aujourd'hui, avec la b�n�diction de nos parents et de nos pasteurs, nous nous engageons pour l'�ternit� !",
        testimony: "� Nous savons, du reste, que toutes choses concourent au bien de ceux qui aiment Dieu � (Romains 8:28). Malgr� les d�fis, la fid�lit� de l'�ternel a guid� chaque pas de notre cheminement.",
        weddingDate: "15 Novembre 2025",
        dotDate: "13 Septembre 2025 � 10h00 (Domicile Familial Yao - Cocody)",
        civilDate: "15 Novembre 2025 � 09h30 (Mairie de Cocody)",
        churchDate: "15 Novembre 2025 � 11h30 (�glise �vang�lique Gr�ce et Vie)",
        receptionDate: "15 Novembre 2025 � 14h00 (Espace Nuptial Riviera Golf)",
        venueName: "Espace Nuptial Riviera Golf",
        venueAddress: "Boulevard Fran�ois Mitterrand, Riviera Golf, Abidjan",
        venueMapUrl: "https://maps.google.com/?q=Riviera+Golf+Abidjan",
        heroImageUrl: "https://images.pexels.com/photos/34887758/pexels-photo-34887758.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
        galleryPhotos: [
          "https://images.pexels.com/photos/37828098/pexels-photo-37828098.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800",
          "https://images.pexels.com/photos/37828100/pexels-photo-37828100.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800",
          "https://images.pexels.com/photos/17770297/pexels-photo-17770297.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800",
        ],
        pastorWord: "� Que ce couple soit une maison b�tie sur le roc. Que la lumi�re de Christ brille � travers leur alliance. � - Pasteur Jean-Marc Kouadio",
        blessingMessage: "Votre pr�sence et vos pri�res sont notre plus beau cadeau pour sceller ce grand jour.",
        customVerse: "Eccl�siaste 4:12 - La corde � trois fils ne se rompt pas facilement.",
        isPublished: true,
        rsvpDeadline: "31 Octobre 2025",
      });

      // Seed Cagnotte Foyer
      await db.insert(cagnotteContributions).values([
        { coupleId, donorName: "Tante Marie-Paule Kouassi", donorPhone: "+225 07 08 09 10 11", amount: 100000, message: "Que le Seigneur pourvoie abondamment pour votre installation !", paymentReference: "WAVE-CI-7788991" },
        { coupleId, donorName: "Fr�re Emmanuel & Famille", donorPhone: "+225 05 44 33 22 11", amount: 50000, message: "F�licitations aux futurs mari�s ! Que votre foyer soit b�ni.", paymentReference: "WAVE-CI-8899002" },
        { coupleId, donorName: "Groupe Jeunesse Chr�tienne", donorPhone: "+225 01 23 45 67 89", amount: 75000, message: "Nos pri�res vous accompagnent dans cette magnifique aventure.", paymentReference: "WAVE-CI-9900113" },
      ]);

      // Seed Day J items
      await db.insert(dayJItems).values([
        { coupleId, timeSlot: "06:30 - 08:30", activityTitle: "Mise en beaut� de la mari�e & Pr�paration du mari�", location: "R�sidence Cocody & Riviera", personInCharge: "Esther & Serge", contactPhone: "+225 05 66 77 88 99", orderIndex: 1 },
        { coupleId, timeSlot: "09:00 - 10:30", activityTitle: "C�l�bration du Mariage Civil", location: "Mairie de Cocody - Salle des Mariages", personInCharge: "Protocole Mairie & T�moins", contactPhone: "+225 07 44 55 66 77", orderIndex: 2 },
        { coupleId, timeSlot: "11:00 - 13:00", activityTitle: "Culte de B�n�diction Nuptiale", location: "�glise �vang�lique Gr�ce et Vie", personInCharge: "Pasteur Jean-Marc & Comit� d'Ordre", contactPhone: "+225 07 01 02 03 04", orderIndex: 3 },
        { coupleId, timeSlot: "13:15 - 14:15", activityTitle: "S�ance Photo Officielle des Mari�s & Familles", location: "Jardins de l'Espace Riviera Golf", personInCharge: "Photographe Principal", contactPhone: "+225 01 23 45 67 89", orderIndex: 4 },
        { coupleId, timeSlot: "14:30 - 18:00", activityTitle: "Grande R�ception, Banquet & Mur de B�n�dictions", location: "Grande Salle Nuptiale Riviera Golf", personInCharge: "Ma�tre de C�r�monie & Traiteur", contactPhone: "+225 07 88 99 00 11", orderIndex: 5 },
      ]);

      // Seed Day J Blessings
      await db.insert(dayJBlessings).values([
        { coupleId, senderName: "Papy Yao & M�m� Yao", senderRelation: "Grands-Parents", blessingText: "Que l'�ternel fasse briller Sa face sur vous et qu'Il vous accorde Sa paix tout au long de votre vie.", isApprovedForScreen: true },
        { coupleId, senderName: "Jeunesse Gr�ce et Vie", senderRelation: "Amis de Foi", blessingText: "�poux et �pouse, vous �tes une source d'inspiration pour nous tous. Gloire � Dieu pour votre amour pur !", isApprovedForScreen: true },
        { coupleId, senderName: "Famille Bamba", senderRelation: "Voisins et Amis", blessingText: "Plein de bonheur, de prosp�rit� et une abondance de gr�ces divines sur votre nouveau foyer !", isApprovedForScreen: true },
      ]);

      // Seed Sample Payment Record (Formule Couple 3 000 FCFA)
      await db.insert(payments).values({
        coupleId,
        amount: 3000,
        planType: "couple",
        payerEmail: "�poux@weddingmood.ci",
        payerPartner: "partner1",
        paymentDate: "2025-08-01",
        referenceNumber: "WAVE-M_W9fOyOGfFiNN-20250801",
        status: "verified",
        adminNotes: "R�glement Wave de 3 000 FCFA valid� manuellement. Acc�s actif pour les deux partenaires avec le code WM-2025.",
        reviewedAt: new Date(),
      });
    }
  } catch (err) {
    console.error("Error during database seed:", err);
  }
}

