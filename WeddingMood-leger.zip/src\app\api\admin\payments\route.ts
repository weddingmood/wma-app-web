import { getCurrentSession } from "@/lib/auth-helpers";
import { db } from "@/db";
import { payments, couples, notifications } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  const session = await getCurrentSession();
  if (!session?.isAdmin) {
    return Response.json({ success: false, message: "Acc�s administrateur requis" }, { status: 403 });
  }

  const allPayments = await db.select().from(payments).orderBy(desc(payments.createdAt));
  const coupleList = await db.select().from(couples);
  const coupleMap = new Map();
  for (const c of coupleList) {
    coupleMap.set(c.id, c);
  }

  const enriched = allPayments.map((p) => {
    const c = coupleMap.get(p.coupleId);
    return {
      ...p,
      coupleName: c ? `${c.partner1Name} & ${c.partner2Name}` : "Couple inconnu",
      coupleEmail: c ? c.partner1Email : "",
      partner2Email: c ? c.partner2Email : "",
      accessCode: c ? c.accessCode : "",
      coupleStatus: c ? c.status : "unknown",
      coupleCity: c ? c.city : "",
    };
  });

  return Response.json({ success: true, payments: enriched });
}

export async function PATCH(req: Request) {
  const session = await getCurrentSession();
  if (!session?.isAdmin) {
    return Response.json({ success: false, message: "Acc�s administrateur requis" }, { status: 403 });
  }

  const body = await req.json();
  const { id, action, adminNotes, rejectionReason } = body;

  if (!id || !action) {
    return Response.json({ success: false, message: "ID et action requis" }, { status: 400 });
  }

  const [payment] = await db.select().from(payments).where(eq(payments.id, Number(id))).limit(1);
  if (!payment) {
    return Response.json({ success: false, message: "Paiement introuvable" }, { status: 404 });
  }

  if (action === "accept") {
    const [updatedPayment] = await db
      .update(payments)
      .set({
        status: "verified",
        adminNotes: adminNotes || "Paiement Wave v�rifi� et valid� par l'administrateur.",
        reviewedAt: new Date(),
        reviewedBy: session.adminId || null,
      })
      .where(eq(payments.id, Number(id)))
      .returning();

    // Activation du compte selon la formule r�gl�e
    const isCouplePlan = payment.planType !== "individual";

    const [activatedCouple] = await db
      .update(couples)
      .set({
        status: "active",
        planType: payment.planType || "couple",
        planAmount: payment.amount || (isCouplePlan ? 3000 : 2000),
        partner1AccessActive: true,
        partner2AccessActive: isCouplePlan,
        updatedAt: new Date(),
      })
      .where(eq(couples.id, payment.coupleId))
      .returning();

    // Notification incluant le code d'acc�s unique du couple
    await db.insert(notifications).values({
      coupleId: payment.coupleId,
      recipient: "both",
      title: "Compte Wedding Mood Actif !",
      message: isCouplePlan
        ? `Votre r�glement de ${(payment.amount || 3000).toLocaleString("fr-FR")} FCFA est valid�. Les deux partenaires peuvent d�sormais se connecter avec leur email personnel et le code d'acc�s ${activatedCouple.accessCode}.`
        : `Votre r�glement de ${(payment.amount || 2000).toLocaleString("fr-FR")} FCFA est valid�. Votre acc�s individuel est actif avec le code ${activatedCouple.accessCode}.`,
      type: "payment",
      linkUrl: "/dashboard/subscription",
    });

    return Response.json({ success: true, message: "Paiement valid� avec succ�s", payment: updatedPayment });
  }

  if (action === "reject") {
    const [updatedPayment] = await db
      .update(payments)
      .set({
        status: "rejected",
        rejectionReason: rejectionReason || "R�f�rence Wave introuvable ou non conforme.",
        adminNotes: adminNotes || "",
        reviewedAt: new Date(),
        reviewedBy: session.adminId || null,
      })
      .where(eq(payments.id, Number(id)))
      .returning();

    await db
      .update(couples)
      .set({
        status: "pending_payment",
        updatedAt: new Date(),
      })
      .where(eq(couples.id, payment.coupleId));

    return Response.json({ success: true, message: "Paiement rejet�", payment: updatedPayment });
  }

  if (action === "request_new_proof") {
    const [updatedPayment] = await db
      .update(payments)
      .set({
        status: "need_new_proof",
        rejectionReason: rejectionReason || "Preuve illisible ou incompl�te. Veuillez renvoyer une capture d'�cran nette.",
        adminNotes: adminNotes || "",
        reviewedAt: new Date(),
        reviewedBy: session.adminId || null,
      })
      .where(eq(payments.id, Number(id)))
      .returning();

    await db
      .update(couples)
      .set({
        status: "verification",
        updatedAt: new Date(),
      })
      .where(eq(couples.id, payment.coupleId));

    return Response.json({ success: true, message: "Nouvelle preuve demand�e", payment: updatedPayment });
  }

  return Response.json({ success: false, message: "Action non support�e" }, { status: 400 });
}

